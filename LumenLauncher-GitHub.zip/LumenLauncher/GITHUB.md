# Compilar Lumen con el NDK (sin instalar nada)

1. Crea un repositorio en GitHub y sube **todo el contenido** de esta carpeta (incluida `.github/`).
2. Entra en la pestaña **Actions** → **build-apk** → **Run workflow** (o simplemente haz un push).
3. Al terminar (5–10 min), abre la ejecución y descarga el artefacto **Lumen-debug-apk**: dentro está el `.apk`.

Qué compila: la app Kotlin/Compose de siempre + `engine/` (el motor nativo en C++) empaquetado como
`liblumen_native.so` para arm64. `NativeEngine.translate()` ya está disponible desde Kotlin.

Qué NO hace todavía: no hay enganche con Minecraft Bedrock (fase 2c de `engine/ENGINE.md`), así que los
shaders no se verán dentro del juego. La vista previa con WebGL2 vive en el APK hecho a mano
(Lumen-0.2.0.apk), no en esta app Compose.

Nada de esto se ha compilado con Gradle ni con el NDK: si el workflow falla, copia el error de la
pestaña Actions y lo corrijo.
