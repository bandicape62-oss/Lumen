# Lumen: launcher de shaders de Java para Minecraft Bedrock (Android)

Fase 1: interfaz y gestor de packs. Proyecto de Android Studio (Kotlin + Jetpack Compose).

> **Estado:** el código está escrito pero **no se ha compilado ni probado en un dispositivo**.
> Puede necesitar ajustes menores al abrirlo por primera vez. Los parsers (`core/`) son Kotlin puro y
> tienen pruebas unitarias en `app/src/test` (`./gradlew test`).

## Qué hace hoy

- Importa shaderpacks de Java en `.zip` (OptiFine/Iris), con o sin carpeta envolvente.
- Valida la estructura (`shaders/` con `.vsh`/`.fsh`) y lee `shaders.properties`.
- Extrae las opciones del pack (`#define`, `//#define`, `#define X 1 // [1 2 3]`, `const ... // [..]`) y deja
  cambiarlas desde la app (se guardan por pack).
- Estima la compatibilidad móvil: geometry shaders, compute/imageLoad/SSBO, GLSL 4.x, número de pasadas,
  mapa de sombras grande, IDs de bloque de Java, `iris.features.required`.
  Nada depende de la versión de Minecraft Java para la que se hizo el pack.
- Detecta Minecraft Bedrock (`com.mojang.minecraftpe`), su versión y si trae `libminecraftpe.so`.
- Tres perfiles de rendimiento (Calidad, Equilibrado, Rendimiento).
- Al pulsar Jugar escribe `files/launch_config.json` y abre Minecraft.

## Qué NO hace todavía

**No ejecuta shaders.** El motor de render es la fase 2 y es la parte difícil:

1. Cargar `libminecraftpe.so` del juego instalado dentro del proceso de Lumen.
2. Interceptar EGL/GLES (`eglSwapBuffers`, draws) para capturar profundidad, normales y mapa de sombras.
3. Ejecutar los pases del pack: traducir GLSL de escritorio (120/330+) a GLSL ES, implementar los uniforms,
   buffers y etapas de OptiFine/Iris (`gbuffers_*`, `shadow`, `composite*`, `final`).
4. Tabla de equivalencias de bloques Java -> Bedrock para `block.properties`.

El riesgo principal es que los puntos de enganche del render cambian entre versiones de Bedrock.

## Contrato con el motor: `launch_config.json`

```json
{
  "schema": 1,
  "createdAt": 1762300000000,
  "bedrock": { "package": "com.mojang.minecraftpe", "versionName": "1.21.x", "versionCode": 0 },
  "pack": {
    "id": "a1b2c3d4",
    "name": "NombreDelPack",
    "path": "/data/data/dev.lumen.launcher/files/packs/a1b2c3d4/pack.zip",
    "options": { "SHADOW_QUALITY": "3", "WAVES": "0" }
  },
  "optimization": {
    "profile": "BALANCED", "targetFps": 60, "dynamicResolution": true,
    "minScale": 0.7, "maxScale": 1.0, "shadowResolution": 1536,
    "shadowDistance": 48, "shadowUpdateEvery": 2, "effectsQuality": 0.85
  }
}
```

- `pack` es `null` si el usuario eligió "Sin shader".
- `options` solo trae las opciones que el usuario cambió; el motor completa el resto con los valores por
  defecto que vienen en los propios `.glsl`. Toggles: `"1"` activado, `"0"` desactivado.

## Estructura

```
app/src/main/java/dev/lumen/launcher/
  core/   Kotlin puro: PackScanner, OptionParser, PropertiesParser, perfiles
  data/   PackRepository (importar/listar), BedrockInstall, LaunchConfigWriter, Prefs
  ui/     Compose: Inicio, Packs, Ajustes
```

## Abrir el proyecto

Android Studio (Ladybug o más reciente) -> *Open* -> carpeta `LumenLauncher`. Si falta el Gradle wrapper,
Android Studio ofrece descargar Gradle 8.9; también sirve `gradle wrapper --gradle-version 8.9`.

## Sobre MagicLoader

Este proyecto está inspirado en la idea de MagicLoader, pero **no incluye ni reutiliza su código ni sus
binarios** (`libmagicloader_host.so`, dex). El APK no declara licencia de reutilización para ellos.
Los valores de los perfiles y el formato de importación son propios.
