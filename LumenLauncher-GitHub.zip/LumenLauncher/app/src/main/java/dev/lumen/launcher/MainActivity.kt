package dev.lumen.launcher

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import dev.lumen.launcher.ui.AppViewModel
import dev.lumen.launcher.ui.LumenApp
import dev.lumen.launcher.ui.LumenTheme

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { LumenTheme { LumenApp(vm) } }
    }

    override fun onResume() {
        super.onResume()
        vm.refreshBedrock() // por si el usuario instaló o actualizó Minecraft mientras tanto
    }
}
