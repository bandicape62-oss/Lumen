package dev.lumen.launcher

/** Puente al motor nativo (engine/). Traduce GLSL de escritorio a GLSL ES 3.00. */
object NativeEngine {
    init { System.loadLibrary("lumen_native") }

    /** Devuelve GLSL ES 3.00, o un texto que empieza por "!" con el motivo si la pasada no puede ejecutarse. */
    external fun translate(source: String, vertex: Boolean): String
}
