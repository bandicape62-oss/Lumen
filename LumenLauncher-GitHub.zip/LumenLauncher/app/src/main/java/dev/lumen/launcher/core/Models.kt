package dev.lumen.launcher.core

enum class Severity { INFO, WARNING, BLOCKER }

data class CompatIssue(val severity: Severity, val message: String)

/** Qué tan probable es que el pack funcione en una GPU móvil con OpenGL ES. */
enum class Compat { GOOD, PARTIAL, POOR }

/** Opción editable de un shaderpack de Java (los `#define ... // [a b c]` de OptiFine/Iris). */
data class PackOption(
    val name: String,
    val kind: Kind,
    val default: String,
    val values: List<String>,
    val file: String
) {
    enum class Kind { TOGGLE, CHOICE }
}

data class PackInfo(
    val name: String,
    val sizeBytes: Long,
    val fileCount: Int,
    val dimensions: List<String>,
    val passCount: Int,
    val hasShadow: Boolean,
    val maxGlslVersion: Int,
    val options: List<PackOption>,
    val issues: List<CompatIssue>,
    val compat: Compat
)

sealed interface ScanResult {
    data class Valid(val info: PackInfo) : ScanResult
    data class Invalid(val reason: String) : ScanResult
}
