package dev.lumen.launcher.core

/** Perfiles de rendimiento. El motor de render los lee desde launch_config.json. */
enum class OptimizationProfile(
    val label: String,
    val summary: String,
    val targetFps: Int,
    val dynamicResolution: Boolean,
    val minScale: Float,
    val maxScale: Float,
    val shadowResolution: Int,
    val shadowDistance: Int,
    val shadowUpdateEvery: Int,
    val effectsQuality: Float
) {
    QUALITY(
        "Calidad", "Resolución completa y sombras nítidas. Para móviles con margen.",
        targetFps = 60, dynamicResolution = false, minScale = 1.0f, maxScale = 1.0f,
        shadowResolution = 2048, shadowDistance = 64, shadowUpdateEvery = 1, effectsQuality = 1.0f
    ),
    BALANCED(
        "Equilibrado", "Baja la resolución solo cuando la GPU no llega a 60 fps.",
        targetFps = 60, dynamicResolution = true, minScale = 0.7f, maxScale = 1.0f,
        shadowResolution = 1536, shadowDistance = 48, shadowUpdateEvery = 2, effectsQuality = 0.85f
    ),
    PERFORMANCE(
        "Rendimiento", "Resolución del 50 al 90 %, sombras ligeras y efectos a media calidad.",
        targetFps = 60, dynamicResolution = true, minScale = 0.5f, maxScale = 0.9f,
        shadowResolution = 512, shadowDistance = 32, shadowUpdateEvery = 3, effectsQuality = 0.6f
    );

    companion object {
        fun fromName(name: String?): OptimizationProfile =
            entries.firstOrNull { it.name == name } ?: BALANCED
    }
}
