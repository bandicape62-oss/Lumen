package dev.lumen.launcher.core

import dev.lumen.launcher.core.PackOption.Kind

/**
 * Extrae las opciones configurables de un archivo de shader, igual que OptiFine/Iris:
 *  - `#define NOMBRE`            -> interruptor activado
 *  - `//#define NOMBRE`          -> interruptor desactivado
 *  - `#define NOMBRE 1.0 // [0.5 1.0 2.0]`   -> lista de valores
 *  - `const float NOMBRE = 1.0; // [0.5 1.0]` -> lista de valores
 * Los toggles usan "1" (activado) y "0" (desactivado).
 */
object OptionParser {
    private val ACTIVE = Regex("""^\s*#\s*define\s+([A-Za-z_]\w*)(?:[ \t]+(.*?))?\s*$""")
    private val DISABLED = Regex("""^\s*//\s*#\s*define\s+([A-Za-z_]\w*)\s*(?://.*)?$""")
    private val IFNDEF = Regex("""^\s*#\s*ifndef\s+([A-Za-z_]\w*)""")
    private val CONST = Regex("""^\s*const\s+(?:int|float|bool)\s+([A-Za-z_]\w*)\s*=\s*([^;]+);\s*//\s*(.*)$""")
    private val BRACKET = Regex("""\[([^\]]*)]""")
    private val SPACES = Regex("""\s+""")

    fun parse(file: String, text: String): List<PackOption> {
        val out = ArrayList<PackOption>()
        var pendingGuard: String? = null

        for (raw in text.lineSequence()) {
            val line = raw.trimEnd()
            if (line.isBlank()) continue
            val guard = pendingGuard
            pendingGuard = null

            val ifndef = IFNDEF.find(line)
            if (ifndef != null) {
                pendingGuard = ifndef.groupValues[1]
                continue
            }

            val disabled = DISABLED.matchEntire(line)
            if (disabled != null) {
                out += toggle(disabled.groupValues[1], "0", file)
                continue
            }

            val active = ACTIVE.matchEntire(line)
            if (active != null) {
                val name = active.groupValues[1]
                if (name == guard) continue // `#ifndef X` + `#define X` = guarda de include, no una opción
                val rest = active.groupValues[2]
                val commentAt = rest.indexOf("//")
                val value = (if (commentAt >= 0) rest.substring(0, commentAt) else rest).trim()
                val comment = if (commentAt >= 0) rest.substring(commentAt + 2) else ""
                if (value.isEmpty()) {
                    out += toggle(name, "1", file)
                } else {
                    val values = bracketValues(comment) ?: continue
                    out += choice(name, value, values, file)
                }
                continue
            }

            val const = CONST.matchEntire(line)
            if (const != null) {
                val values = bracketValues(const.groupValues[3]) ?: continue
                out += choice(const.groupValues[1], const.groupValues[2].trim(), values, file)
            }
        }
        return out
    }

    private fun bracketValues(comment: String): List<String>? {
        val m = BRACKET.find(comment) ?: return null
        val values = m.groupValues[1].trim().split(SPACES).filter { it.isNotEmpty() }
        return values.ifEmpty { null }
    }

    private fun toggle(name: String, default: String, file: String) =
        PackOption(name, Kind.TOGGLE, default, listOf("0", "1"), file)

    private fun choice(name: String, default: String, values: List<String>, file: String): PackOption {
        val all = if (default in values) values else listOf(default) + values
        return PackOption(name, Kind.CHOICE, default, all, file)
    }
}
