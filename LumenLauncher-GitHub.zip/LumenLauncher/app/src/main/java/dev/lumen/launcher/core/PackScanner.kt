package dev.lumen.launcher.core

/**
 * Analiza un shaderpack de Java (formato OptiFine/Iris) sin ejecutarlo:
 * valida su estructura, extrae las opciones y estima cómo se llevará en una GPU móvil.
 * No depende de la versión de Minecraft Java para la que se hizo el pack.
 */
object PackScanner {
    private const val MAX_FILES = 600
    private const val MAX_TOTAL_CHARS = 16 * 1024 * 1024
    private const val MAX_OPTIONS = 400
    private const val MAX_PASSES_COMFORTABLE = 12
    private const val BIG_SHADOW_MAP = 4096

    private val TEXT_EXT = setOf("vsh", "fsh", "gsh", "csh", "glsl", "inc", "h")
    private val STAGE_EXT = setOf("vsh", "fsh", "gsh", "csh")
    private val VERSION = Regex("""^\s*#\s*version\s+(\d+)""", RegexOption.MULTILINE)
    private val IMAGE_OPS = Regex("""\b(imageLoad|imageStore|imageAtomic\w*)\b""")
    private val SSBO = Regex("""\bstd430\b|\bbuffer\s+\w+\s*\{""")
    private val SHADOW_RES = Regex("""const\s+int\s+shadowMapResolution\s*=\s*(\d+)""")
    private val PASS_NAME = Regex("""^(composite|deferred|prepare|begin)\d*(_[a-z])?$""")
    private val DIMENSION = Regex("""^shaders/(world-?\d+)/""")
    private val PASS_FILE = Regex("""^shaders/(?:(world-?\d+)/)?([^/]+)\.fsh$""")
    private val SHADOW_FILE = Regex("""(^|/)shadow\.(fsh|vsh)$""")

    fun scan(source: PackSource, name: String): ScanResult {
        val entries = source.entries
        val shaderEntries = entries.filter { it.startsWith("shaders/") }
        if (shaderEntries.none { it.endsWith(".fsh") || it.endsWith(".vsh") }) {
            return ScanResult.Invalid(
                "No hay una carpeta shaders/ con archivos .vsh o .fsh. " +
                    "Lumen importa shaderpacks de Java en .zip (OptiFine/Iris)."
            )
        }

        var maxVersion = 0
        var usesImages = false
        var usesSsbo = false
        var shadowRes = 0
        var charsRead = 0L
        val options = LinkedHashMap<String, PackOption>()

        val textFiles = shaderEntries.filter { extOf(it) in TEXT_EXT }.take(MAX_FILES)
        for (path in textFiles) {
            if (charsRead > MAX_TOTAL_CHARS) break
            val text = source.readText(path) ?: continue
            charsRead += text.length

            if (extOf(path) in STAGE_EXT) {
                VERSION.find(text)?.let { m ->
                    maxVersion = maxOf(maxVersion, m.groupValues[1].toIntOrNull() ?: 0)
                }
            }
            if (!usesImages && IMAGE_OPS.containsMatchIn(text)) usesImages = true
            if (!usesSsbo && SSBO.containsMatchIn(text)) usesSsbo = true
            SHADOW_RES.find(text)?.let { m ->
                shadowRes = maxOf(shadowRes, m.groupValues[1].toIntOrNull() ?: 0)
            }
            if (options.size < MAX_OPTIONS) {
                for (o in OptionParser.parse(path, text)) options.putIfAbsent(o.name, o)
            }
        }

        val geometryCount = shaderEntries.count { it.endsWith(".gsh") }
        val computeCount = shaderEntries.count { it.endsWith(".csh") }
        val hasShadow = entries.any { SHADOW_FILE.containsMatchIn(it) }

        val passes = HashSet<String>()
        for (e in shaderEntries) {
            val m = PASS_FILE.matchEntire(e) ?: continue
            if (PASS_NAME.matches(m.groupValues[2])) passes += m.groupValues[1] + "/" + m.groupValues[2]
        }

        val dimensions = shaderEntries.mapNotNull { DIMENSION.find(it)?.groupValues?.get(1) }
            .distinct().sorted()

        val props = source.readText("shaders/shaders.properties")?.let { PropertiesParser.parse(it) }
            ?: emptyMap()

        val issues = ArrayList<CompatIssue>()
        if (geometryCount > 0) {
            issues += CompatIssue(
                Severity.BLOCKER,
                "Usa geometry shaders ($geometryCount archivos). OpenGL ES móvil no los admite: " +
                    "esas pasadas se omitirán y el resultado puede verse incorrecto."
            )
        }
        if (computeCount > 0) {
            issues += CompatIssue(
                Severity.WARNING,
                "Usa compute shaders ($computeCount archivos). Requieren OpenGL ES 3.1 o superior."
            )
        }
        if (usesImages || usesSsbo) {
            issues += CompatIssue(
                Severity.WARNING,
                "Usa imageLoad/imageStore o buffers de almacenamiento. Requiere OpenGL ES 3.1 o superior."
            )
        }
        if (maxVersion >= 400) {
            issues += CompatIssue(
                Severity.WARNING,
                "Está escrito en GLSL $maxVersion. Hay que traducirlo a GLSL ES y algunas funciones de escritorio no tienen equivalente."
            )
        }
        if (passes.size > MAX_PASSES_COMFORTABLE) {
            issues += CompatIssue(
                Severity.WARNING,
                "Tiene ${passes.size} pasadas de postproceso. Es pesado para una GPU móvil."
            )
        }
        if (shadowRes >= BIG_SHADOW_MAP) {
            issues += CompatIssue(
                Severity.WARNING,
                "Pide un mapa de sombras de $shadowRes px. En móvil conviene bajarlo desde sus opciones."
            )
        }
        if (hasShadow) {
            issues += CompatIssue(Severity.INFO, "Calcula sombras con mapa de sombras, que cuesta bastante en GPU móvil.")
        }
        if (source.readText("shaders/block.properties", 1) != null || props.keys.any { it.startsWith("block.") }) {
            issues += CompatIssue(
                Severity.INFO,
                "Asigna IDs a bloques de Java (block.properties). Los bloques de Bedrock necesitan una tabla de equivalencias."
            )
        }
        props["iris.features.required"]?.takeIf { it.isNotBlank() }?.let {
            issues += CompatIssue(Severity.INFO, "Declara que requiere características de Iris: $it.")
        }

        val compat = when {
            issues.any { it.severity == Severity.BLOCKER } -> Compat.POOR
            issues.any { it.severity == Severity.WARNING } -> Compat.PARTIAL
            else -> Compat.GOOD
        }

        return ScanResult.Valid(
            PackInfo(
                name = name,
                sizeBytes = source.totalBytes,
                fileCount = entries.size,
                dimensions = dimensions,
                passCount = passes.size,
                hasShadow = hasShadow,
                maxGlslVersion = maxVersion,
                options = options.values.toList(),
                issues = issues,
                compat = compat
            )
        )
    }

    private fun extOf(path: String): String = path.substringAfterLast('.', "").lowercase()
}
