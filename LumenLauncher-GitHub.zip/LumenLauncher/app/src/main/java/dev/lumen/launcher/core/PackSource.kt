package dev.lumen.launcher.core

import java.io.ByteArrayOutputStream
import java.io.File
import java.util.zip.ZipFile

/**
 * Árbol de archivos de un shaderpack, sin depender de Android.
 * Las rutas son relativas a la raíz del pack (la carpeta que contiene `shaders/`).
 */
interface PackSource : AutoCloseable {
    val entries: List<String>
    val totalBytes: Long
    fun readText(path: String, maxBytes: Int = 256 * 1024): String?
}

/** Lee un .zip. Si el zip trae una carpeta envolvente (`MiPack/shaders/...`) la ignora. */
class ZipPackSource(file: File) : PackSource {
    private val zip = ZipFile(file)
    private val prefix: String
    override val entries: List<String>
    override val totalBytes: Long

    init {
        val files = zip.entries().asSequence().filter { !it.isDirectory }.toList()
        val names = files.map { it.name.replace('\\', '/') }
        prefix = detectRoot(names)
        entries = names.filter { it.startsWith(prefix) }.map { it.removePrefix(prefix) }
        totalBytes = files.filter { it.name.replace('\\', '/').startsWith(prefix) }
            .sumOf { it.size.coerceAtLeast(0L) }
    }

    override fun readText(path: String, maxBytes: Int): String? {
        val entry = zip.getEntry(prefix + path) ?: return null
        zip.getInputStream(entry).use { input ->
            val out = ByteArrayOutputStream()
            val buf = ByteArray(8192)
            var total = 0
            while (true) {
                val n = input.read(buf)
                if (n < 0) break
                total += n
                if (total > maxBytes) break
                out.write(buf, 0, n)
            }
            return out.toString(Charsets.UTF_8.name())
        }
    }

    override fun close() = zip.close()

    companion object {
        /** "" si `shaders/` está en la raíz; "Carpeta/" si hay una única carpeta envolvente. */
        internal fun detectRoot(names: List<String>): String {
            if (names.any { it.startsWith("shaders/") }) return ""
            val candidates = names.mapNotNull { n ->
                val i = n.indexOf("/shaders/")
                if (i > 0 && n.substring(0, i).indexOf('/') < 0) n.substring(0, i + 1) else null
            }.distinct()
            return candidates.singleOrNull() ?: ""
        }
    }
}

/** Fuente en memoria, útil para pruebas. */
class InMemoryPackSource(private val files: Map<String, String>) : PackSource {
    override val entries: List<String> get() = files.keys.toList()
    override val totalBytes: Long get() = files.values.sumOf { it.length.toLong() }
    override fun readText(path: String, maxBytes: Int): String? = files[path]?.take(maxBytes)
    override fun close() = Unit
}
