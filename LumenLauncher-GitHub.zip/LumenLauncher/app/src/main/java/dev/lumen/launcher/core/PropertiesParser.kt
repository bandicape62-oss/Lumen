package dev.lumen.launcher.core

/** Lector de `shaders.properties` (clave=valor, `#` comentarios, `\` al final = continúa en la línea siguiente). */
object PropertiesParser {
    fun parse(text: String): Map<String, String> {
        val result = LinkedHashMap<String, String>()
        val pending = StringBuilder()
        for (raw in text.lineSequence()) {
            val line = raw.trimEnd()
            if (pending.isEmpty()) {
                val t = line.trimStart()
                if (t.isEmpty() || t.startsWith("#")) continue
            }
            if (line.endsWith("\\")) {
                pending.append(line.dropLast(1).trim()).append(' ')
                continue
            }
            pending.append(line.trim())
            val full = pending.toString()
            pending.setLength(0)
            val eq = full.indexOf('=')
            if (eq <= 0) continue
            result[full.substring(0, eq).trim()] = full.substring(eq + 1).trim()
        }
        return result
    }
}
