package dev.lumen.launcher.data

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import java.io.File

data class BedrockStatus(
    val installed: Boolean,
    val versionName: String? = null,
    val versionCode: Long = 0L,
    val hasNativeLib: Boolean = false
)

/** Consulta y abre Minecraft Bedrock (versión de Google Play). */
object BedrockInstall {
    const val PACKAGE = "com.mojang.minecraftpe"

    fun status(context: Context): BedrockStatus {
        val pm = context.packageManager
        return try {
            val info = if (Build.VERSION.SDK_INT >= 33) {
                pm.getPackageInfo(PACKAGE, PackageManager.PackageInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageInfo(PACKAGE, 0)
            }
            val libDir = info.applicationInfo?.nativeLibraryDir
            BedrockStatus(
                installed = true,
                versionName = info.versionName,
                versionCode = info.longVersionCode,
                hasNativeLib = libDir != null && File(libDir, "libminecraftpe.so").exists()
            )
        } catch (e: PackageManager.NameNotFoundException) {
            BedrockStatus(installed = false)
        }
    }

    fun launch(context: Context): Boolean {
        val intent = context.packageManager.getLaunchIntentForPackage(PACKAGE) ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        return true
    }
}
