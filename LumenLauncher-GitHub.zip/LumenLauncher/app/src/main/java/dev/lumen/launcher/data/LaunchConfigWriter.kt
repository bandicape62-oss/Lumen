package dev.lumen.launcher.data

import android.content.Context
import dev.lumen.launcher.core.OptimizationProfile
import org.json.JSONObject
import java.io.File

/**
 * Escribe `files/launch_config.json`: el contrato entre este launcher y el motor de render
 * (fase 2). El motor, que correrá en el mismo proceso, lee este archivo al arrancar el juego.
 * Ver README.md para el significado de cada campo.
 */
object LaunchConfigWriter {
    const val SCHEMA = 1

    fun write(
        context: Context,
        bedrock: BedrockStatus,
        pack: StoredPack?,
        profile: OptimizationProfile
    ): File {
        val json = JSONObject()
            .put("schema", SCHEMA)
            .put("createdAt", System.currentTimeMillis())
            .put(
                "bedrock",
                JSONObject()
                    .put("package", BedrockInstall.PACKAGE)
                    .put("versionName", bedrock.versionName ?: JSONObject.NULL)
                    .put("versionCode", bedrock.versionCode)
            )
            .put(
                "pack",
                if (pack == null) JSONObject.NULL else JSONObject()
                    .put("id", pack.id)
                    .put("name", pack.info.name)
                    .put("path", pack.zip.absolutePath)
                    .put("options", JSONObject().also { o -> pack.overrides.forEach { (k, v) -> o.put(k, v) } })
            )
            .put(
                "optimization",
                JSONObject()
                    .put("profile", profile.name)
                    .put("targetFps", profile.targetFps)
                    .put("dynamicResolution", profile.dynamicResolution)
                    .put("minScale", profile.minScale.toDouble())
                    .put("maxScale", profile.maxScale.toDouble())
                    .put("shadowResolution", profile.shadowResolution)
                    .put("shadowDistance", profile.shadowDistance)
                    .put("shadowUpdateEvery", profile.shadowUpdateEvery)
                    .put("effectsQuality", profile.effectsQuality.toDouble())
            )
        val out = File(context.filesDir, "launch_config.json")
        out.writeText(json.toString(2))
        return out
    }
}
