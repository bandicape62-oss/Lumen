package dev.lumen.launcher.data

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import dev.lumen.launcher.core.PackInfo
import dev.lumen.launcher.core.PackScanner
import dev.lumen.launcher.core.ScanResult
import dev.lumen.launcher.core.ZipPackSource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.util.UUID
import java.util.zip.ZipException

data class StoredPack(
    val id: String,
    val info: PackInfo,
    val zip: File,
    val importedAt: Long,
    /** Opciones que el usuario cambió respecto a los valores por defecto del pack. */
    val overrides: Map<String, String>
)

sealed interface ImportOutcome {
    data class Imported(val pack: StoredPack) : ImportOutcome
    data class Failed(val message: String) : ImportOutcome
}

/**
 * Guarda cada pack en `files/packs/<id>/` con su `pack.zip` y un `meta.json`.
 * Al listar se vuelve a analizar el zip, así el análisis siempre está al día con el código.
 */
class PackRepository(private val context: Context) {
    private val root = File(context.filesDir, "packs").also { it.mkdirs() }

    fun list(): List<StoredPack> =
        (root.listFiles { f -> f.isDirectory } ?: emptyArray())
            .mapNotNull { readStored(it) }
            .sortedByDescending { it.importedAt }

    suspend fun import(uri: Uri): ImportOutcome = withContext(Dispatchers.IO) {
        val baseName = (queryName(uri) ?: "pack").removeSuffix(".zip").removeSuffix(".ZIP")
        val tmp = File(context.cacheDir, "import_${System.nanoTime()}.zip")
        try {
            val copied = context.contentResolver.openInputStream(uri)?.use { input ->
                tmp.outputStream().use { input.copyTo(it) }
                true
            } ?: false
            if (!copied) return@withContext ImportOutcome.Failed("No se pudo abrir el archivo.")

            val scan = try {
                ZipPackSource(tmp).use { PackScanner.scan(it, baseName) }
            } catch (e: ZipException) {
                return@withContext ImportOutcome.Failed("El archivo no es un .zip válido.")
            }

            when (scan) {
                is ScanResult.Invalid -> ImportOutcome.Failed(scan.reason)
                is ScanResult.Valid -> {
                    val id = UUID.nameUUIDFromBytes("$baseName:${tmp.length()}".toByteArray())
                        .toString().substring(0, 8)
                    val dir = File(root, id).also { it.mkdirs() }
                    val dest = File(dir, "pack.zip")
                    tmp.copyTo(dest, overwrite = true)
                    val now = System.currentTimeMillis()
                    val overrides = readMeta(dir)?.let { readOverrides(it) } ?: emptyMap()
                    writeMeta(dir, baseName, now, overrides)
                    ImportOutcome.Imported(StoredPack(id, scan.info, dest, now, overrides))
                }
            }
        } catch (e: IOException) {
            ImportOutcome.Failed("No se pudo leer el archivo: ${e.message}")
        } finally {
            tmp.delete()
        }
    }

    fun delete(id: String) {
        if (!ID_FORMAT.matches(id)) return
        File(root, id).deleteRecursively()
    }

    fun saveOverrides(id: String, overrides: Map<String, String>) {
        if (!ID_FORMAT.matches(id)) return
        val dir = File(root, id)
        val meta = readMeta(dir) ?: return
        writeMeta(dir, meta.optString("name", id), meta.optLong("importedAt"), overrides)
    }

    private fun readStored(dir: File): StoredPack? {
        val zip = File(dir, "pack.zip")
        val meta = readMeta(dir) ?: return null
        if (!zip.exists()) return null
        return try {
            val name = meta.getString("name")
            val scan = ZipPackSource(zip).use { PackScanner.scan(it, name) }
            if (scan !is ScanResult.Valid) return null
            StoredPack(dir.name, scan.info, zip, meta.optLong("importedAt"), readOverrides(meta))
        } catch (e: Exception) {
            null
        }
    }

    private fun readMeta(dir: File): JSONObject? {
        val f = File(dir, "meta.json")
        if (!f.exists()) return null
        return try { JSONObject(f.readText()) } catch (e: Exception) { null }
    }

    private fun readOverrides(meta: JSONObject): Map<String, String> {
        val obj = meta.optJSONObject("overrides") ?: return emptyMap()
        val out = LinkedHashMap<String, String>()
        val keys = obj.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            out[k] = obj.getString(k)
        }
        return out
    }

    private fun writeMeta(dir: File, name: String, importedAt: Long, overrides: Map<String, String>) {
        val json = JSONObject()
            .put("name", name)
            .put("importedAt", importedAt)
            .put("overrides", JSONObject().also { o -> overrides.forEach { (k, v) -> o.put(k, v) } })
        File(dir, "meta.json").writeText(json.toString())
    }

    private fun queryName(uri: Uri): String? =
        context.contentResolver
            .query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }

    private companion object {
        val ID_FORMAT = Regex("[0-9a-f]{8}")
    }
}
