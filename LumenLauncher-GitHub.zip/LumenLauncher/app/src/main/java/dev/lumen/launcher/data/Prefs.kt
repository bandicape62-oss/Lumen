package dev.lumen.launcher.data

import android.content.Context
import dev.lumen.launcher.core.OptimizationProfile

class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("lumen", Context.MODE_PRIVATE)

    var activePackId: String?
        get() = sp.getString("active_pack", null)
        set(value) = sp.edit().putString("active_pack", value).apply()

    var profile: OptimizationProfile
        get() = OptimizationProfile.fromName(sp.getString("profile", null))
        set(value) = sp.edit().putString("profile", value.name).apply()
}
