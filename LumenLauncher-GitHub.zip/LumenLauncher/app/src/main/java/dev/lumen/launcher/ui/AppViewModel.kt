package dev.lumen.launcher.ui

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import dev.lumen.launcher.core.OptimizationProfile
import dev.lumen.launcher.core.PackOption
import dev.lumen.launcher.data.BedrockInstall
import dev.lumen.launcher.data.BedrockStatus
import dev.lumen.launcher.data.ImportOutcome
import dev.lumen.launcher.data.LaunchConfigWriter
import dev.lumen.launcher.data.PackRepository
import dev.lumen.launcher.data.Prefs
import dev.lumen.launcher.data.StoredPack
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class UiState(
    val bedrock: BedrockStatus = BedrockStatus(installed = false),
    val packs: List<StoredPack> = emptyList(),
    val activePackId: String? = null,
    val profile: OptimizationProfile = OptimizationProfile.BALANCED,
    val loading: Boolean = true,
    val importing: Boolean = false,
    val message: String? = null
) {
    val activePack: StoredPack? get() = packs.firstOrNull { it.id == activePackId }
}

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = PackRepository(app)
    private val prefs = Prefs(app)

    private val _state = MutableStateFlow(
        UiState(profile = prefs.profile, activePackId = prefs.activePackId)
    )
    val state: StateFlow<UiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            val packs = withContext(Dispatchers.IO) { repo.list() }
            _state.update { it.copy(packs = packs, loading = false) }
        }
        refreshBedrock()
    }

    fun refreshBedrock() {
        viewModelScope.launch {
            val status = withContext(Dispatchers.IO) { BedrockInstall.status(getApplication()) }
            _state.update { it.copy(bedrock = status) }
        }
    }

    fun importPack(uri: Uri) {
        viewModelScope.launch {
            _state.update { it.copy(importing = true) }
            when (val result = repo.import(uri)) {
                is ImportOutcome.Imported -> {
                    val packs = withContext(Dispatchers.IO) { repo.list() }
                    prefs.activePackId = result.pack.id
                    _state.update {
                        it.copy(
                            packs = packs,
                            activePackId = result.pack.id,
                            importing = false,
                            message = "Importado: ${result.pack.info.name}"
                        )
                    }
                }
                is ImportOutcome.Failed -> _state.update {
                    it.copy(importing = false, message = result.message)
                }
            }
        }
    }

    fun selectPack(id: String?) {
        prefs.activePackId = id
        _state.update { it.copy(activePackId = id) }
    }

    fun deletePack(id: String) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { repo.delete(id) }
            if (prefs.activePackId == id) prefs.activePackId = null
            _state.update { s ->
                s.copy(
                    packs = s.packs.filterNot { it.id == id },
                    activePackId = if (s.activePackId == id) null else s.activePackId
                )
            }
        }
    }

    fun setOption(packId: String, option: PackOption, value: String) {
        val pack = _state.value.packs.firstOrNull { it.id == packId } ?: return
        val updated = pack.overrides.toMutableMap()
        if (value == option.default) updated.remove(option.name) else updated[option.name] = value
        viewModelScope.launch(Dispatchers.IO) { repo.saveOverrides(packId, updated) }
        _state.update { s ->
            s.copy(packs = s.packs.map { if (it.id == packId) it.copy(overrides = updated) else it })
        }
    }

    fun setProfile(profile: OptimizationProfile) {
        prefs.profile = profile
        _state.update { it.copy(profile = profile) }
    }

    /** Guarda la configuración para el motor de render y abre Minecraft. */
    fun play(context: Context) {
        val s = _state.value
        if (!s.bedrock.installed) {
            say("Minecraft Bedrock no está instalado en este dispositivo.")
            return
        }
        LaunchConfigWriter.write(context, s.bedrock, s.activePack, s.profile)
        if (!BedrockInstall.launch(context)) say("No se pudo abrir Minecraft.")
    }

    fun clearMessage() = _state.update { it.copy(message = null) }

    private fun say(text: String) = _state.update { it.copy(message = text) }
}
