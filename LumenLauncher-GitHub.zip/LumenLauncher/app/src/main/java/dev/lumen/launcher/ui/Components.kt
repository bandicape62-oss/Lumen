package dev.lumen.launcher.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import dev.lumen.launcher.core.Compat

/** Cielo de atardecer con un sol que se oculta tras un horizonte de bloques. */
@Composable
fun Horizon(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        drawRect(
            brush = Brush.verticalGradient(
                0f to Color(0xFF151A36),
                0.45f to Color(0xFF3A2F6E),
                0.78f to Color(0xFFC25E7C),
                1f to Color(0xFFF0A04B)
            )
        )
        drawCircle(
            color = Color(0xFFFFE6B3),
            radius = size.minDimension * 0.17f,
            center = Offset(size.width * 0.74f, size.height * 0.80f)
        )
        val heights = floatArrayOf(
            .16f, .18f, .18f, .22f, .22f, .20f, .25f, .28f, .28f,
            .24f, .22f, .26f, .30f, .30f, .27f, .23f, .23f, .19f
        )
        val colW = size.width / heights.size
        heights.forEachIndexed { i, h ->
            val top = size.height * (1f - h)
            drawRect(
                color = Color(0xFF1A1030),
                topLeft = Offset(i * colW, top),
                size = Size(colW + 1f, size.height - top)
            )
        }
    }
}

@Composable
fun CompatBadge(compat: Compat, modifier: Modifier = Modifier) {
    val (label, color) = when (compat) {
        Compat.GOOD -> "Buena compatibilidad" to Tide
        Compat.PARTIAL -> "Compatibilidad parcial" to Ember
        Compat.POOR -> "Difícil en móvil" to Coral
    }
    Text(
        text = label,
        style = MaterialTheme.typography.labelMedium,
        color = color,
        modifier = modifier
            .background(color.copy(alpha = 0.16f), RoundedCornerShape(6.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    )
}
