package dev.lumen.launcher.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Composable
fun HomeScreen(state: UiState, onPlay: () -> Unit, onChoosePack: () -> Unit) {
    val pack = state.activePack
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(240.dp)
                .clip(RoundedCornerShape(bottomStart = 40.dp, bottomEnd = 8.dp))
        ) {
            Horizon(Modifier.matchParentSize())
            Column(Modifier.align(Alignment.TopStart).padding(start = 24.dp, top = 28.dp, end = 24.dp)) {
                Text("Lumen", style = MaterialTheme.typography.headlineLarge, color = Color.White)
                Text(
                    "Shaders de Java en Minecraft Bedrock",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.White.copy(alpha = 0.85f)
                )
            }
        }

        Column(Modifier.padding(horizontal = 24.dp, vertical = 20.dp)) {
            InfoRow(
                label = "Minecraft Bedrock",
                value = when {
                    !state.bedrock.installed -> "No está instalado"
                    state.bedrock.versionName != null -> "Versión ${state.bedrock.versionName}"
                    else -> "Instalado"
                },
                valueColor = if (state.bedrock.installed) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.error
            )
            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))
            Row(
                Modifier.fillMaxWidth().clickable(onClick = onChoosePack).padding(vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text("Shader", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(pack?.info?.name ?: "Ninguno", style = MaterialTheme.typography.titleMedium)
                }
                if (pack != null) CompatBadge(pack.info.compat)
            }
            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))
            InfoRow(label = "Perfil", value = "${state.profile.label}. ${state.profile.summary}")

            Button(
                onClick = onPlay,
                enabled = state.bedrock.installed,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth().padding(top = 24.dp).height(56.dp)
            ) {
                Text(
                    if (pack != null) "Jugar con ${pack.info.name}" else "Jugar sin shader",
                    style = MaterialTheme.typography.titleMedium
                )
            }
            Text(
                "El motor de render todavía no está integrado. Por ahora Lumen guarda la configuración y abre Minecraft sin efectos.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 12.dp)
            )
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String, valueColor: Color = MaterialTheme.colorScheme.onSurface) {
    Column(Modifier.fillMaxWidth().padding(vertical = 14.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodyLarge, color = valueColor)
    }
}
