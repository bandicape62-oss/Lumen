package dev.lumen.launcher.ui

import android.text.format.Formatter
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import dev.lumen.launcher.core.CompatIssue
import dev.lumen.launcher.core.PackInfo
import dev.lumen.launcher.core.PackOption
import dev.lumen.launcher.core.Severity
import dev.lumen.launcher.data.StoredPack

private const val MAX_OPTIONS_SHOWN = 60

@Composable
fun PacksScreen(
    state: UiState,
    onImport: () -> Unit,
    onSelect: (String?) -> Unit,
    onDelete: (String) -> Unit,
    onOption: (packId: String, option: PackOption, value: String) -> Unit
) {
    var detailId by remember { mutableStateOf<String?>(null) }
    var pendingDelete by remember { mutableStateOf<StoredPack?>(null) }
    val detail = state.packs.firstOrNull { it.id == detailId }
    val context = LocalContext.current

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(start = 24.dp, end = 20.dp, top = 24.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Packs", style = MaterialTheme.typography.headlineMedium, modifier = Modifier.weight(1f))
            FilledTonalButton(onClick = onImport, enabled = !state.importing) {
                Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text(if (state.importing) "Importando…" else "Importar .zip")
            }
        }

        if (state.packs.isEmpty()) {
            Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Aún no hay packs", style = MaterialTheme.typography.titleLarge)
                Text(
                    "Importa un shaderpack de Java en .zip (OptiFine o Iris). Lumen revisa su estructura, " +
                        "lista sus opciones y te dice si es viable en un móvil.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                item {
                    Row(
                        Modifier.fillMaxWidth().clickable { onSelect(null) }.padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = state.activePackId == null, onClick = { onSelect(null) })
                        Text("Sin shader (Minecraft normal)", style = MaterialTheme.typography.titleMedium)
                    }
                }
                items(state.packs, key = { it.id }) { pack ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { detailId = pack.id }
                            .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(14.dp))
                            .padding(vertical = 10.dp, horizontal = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = state.activePackId == pack.id, onClick = { onSelect(pack.id) })
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(pack.info.name, style = MaterialTheme.typography.titleMedium)
                            Text(
                                "${Formatter.formatShortFileSize(context, pack.info.sizeBytes)}, " +
                                    "${pack.info.options.size} opciones",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            CompatBadge(pack.info.compat)
                        }
                    }
                }
            }
        }
    }

    if (detail != null) {
        AlertDialog(
            onDismissRequest = { detailId = null },
            title = { Text(detail.info.name, style = MaterialTheme.typography.titleLarge) },
            text = { PackDetail(detail, onOption) },
            confirmButton = { TextButton(onClick = { detailId = null }) { Text("Cerrar") } },
            dismissButton = {
                TextButton(onClick = { pendingDelete = detail; detailId = null }) {
                    Text("Quitar pack", color = MaterialTheme.colorScheme.error)
                }
            }
        )
    }

    pendingDelete?.let { pack ->
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            title = { Text("¿Quitar ${pack.info.name}?") },
            text = { Text("Se borra la copia que guardó Lumen. El archivo original no se toca.") },
            confirmButton = {
                TextButton(onClick = { onDelete(pack.id); pendingDelete = null }) { Text("Quitar") }
            },
            dismissButton = { TextButton(onClick = { pendingDelete = null }) { Text("Cancelar") } }
        )
    }
}

@Composable
private fun PackDetail(pack: StoredPack, onOption: (String, PackOption, String) -> Unit) {
    val info = pack.info
    Column(
        Modifier.heightIn(max = 440.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        CompatBadge(info.compat)
        Text(
            summaryLine(info),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        info.issues.forEach { IssueRow(it) }
        if (info.options.isNotEmpty()) {
            Text("Opciones (${info.options.size})", style = MaterialTheme.typography.titleMedium)
            info.options.take(MAX_OPTIONS_SHOWN).forEach { opt ->
                OptionRow(opt, pack.overrides[opt.name] ?: opt.default) { onOption(pack.id, opt, it) }
            }
            if (info.options.size > MAX_OPTIONS_SHOWN) {
                Text(
                    "y ${info.options.size - MAX_OPTIONS_SHOWN} más",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun IssueRow(issue: CompatIssue) {
    val color = when (issue.severity) {
        Severity.BLOCKER -> Coral
        Severity.WARNING -> Ember
        Severity.INFO -> Mist
    }
    Row(verticalAlignment = Alignment.Top) {
        Box(Modifier.padding(top = 7.dp).size(8.dp).background(color, CircleShape))
        Spacer(Modifier.width(10.dp))
        Text(issue.message, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun OptionRow(option: PackOption, value: String, onChange: (String) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(
            option.name,
            style = MaterialTheme.typography.bodySmall,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.weight(1f)
        )
        when (option.kind) {
            PackOption.Kind.TOGGLE -> Switch(checked = value == "1", onCheckedChange = { onChange(if (it) "1" else "0") })
            PackOption.Kind.CHOICE -> {
                var open by remember { mutableStateOf(false) }
                Box {
                    TextButton(onClick = { open = true }) { Text(value) }
                    DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                        option.values.forEach { v ->
                            DropdownMenuItem(text = { Text(v) }, onClick = { onChange(v); open = false })
                        }
                    }
                }
            }
        }
    }
}

private fun summaryLine(info: PackInfo): String = buildList {
    add("${info.passCount} pasadas de postproceso")
    if (info.maxGlslVersion > 0) add("GLSL ${info.maxGlslVersion}")
    if (info.hasShadow) add("con sombras")
    if (info.dimensions.isNotEmpty()) add(info.dimensions.joinToString("/") { dimensionName(it) })
}.joinToString(", ")

private fun dimensionName(folder: String) = when (folder) {
    "world0" -> "Overworld"
    "world-1" -> "Nether"
    "world1" -> "End"
    else -> folder
}
