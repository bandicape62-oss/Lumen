package dev.lumen.launcher.ui

import android.os.Build
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import dev.lumen.launcher.core.OptimizationProfile

@Composable
fun SettingsScreen(state: UiState, onProfile: (OptimizationProfile) -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 24.dp, vertical = 24.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("Ajustes", style = MaterialTheme.typography.headlineMedium)
        Text(
            "Perfil de rendimiento",
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.padding(top = 16.dp)
        )
        OptimizationProfile.entries.forEach { p ->
            Row(
                Modifier.fillMaxWidth().clickable { onProfile(p) }.padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                RadioButton(selected = state.profile == p, onClick = { onProfile(p) })
                Column(Modifier.padding(start = 4.dp)) {
                    Text(p.label, style = MaterialTheme.typography.bodyLarge)
                    Text(p.summary, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }

        HorizontalDivider(Modifier.padding(vertical = 16.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))

        Text("Este dispositivo", style = MaterialTheme.typography.titleMedium)
        Fact("Android", Build.VERSION.RELEASE)
        Fact("Arquitectura", Build.SUPPORTED_ABIS.firstOrNull() ?: "desconocida")
        Fact(
            "Minecraft Bedrock",
            when {
                !state.bedrock.installed -> "No instalado"
                state.bedrock.versionName != null -> state.bedrock.versionName
                else -> "Instalado"
            }
        )
        Fact("Librería nativa del juego", if (state.bedrock.hasNativeLib) "Encontrada" else "No encontrada")
    }
}

@Composable
private fun Fact(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
        Text(value, style = MaterialTheme.typography.bodyMedium)
    }
}
