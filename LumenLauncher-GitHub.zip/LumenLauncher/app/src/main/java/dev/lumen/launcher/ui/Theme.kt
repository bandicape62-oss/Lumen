package dev.lumen.launcher.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// Paleta: el cielo al atardecer sobre un horizonte de bloques.
val Night = Color(0xFF151A36)
val Dusk = Color(0xFF1E2548)
val Twilight = Color(0xFF2B3265)
val Paper = Color(0xFFEDE9E0)
val Mist = Color(0xFFB7B6CE)
val Ember = Color(0xFFF0A04B)
val Tide = Color(0xFF63D2B8)
val Coral = Color(0xFFFF8F7A)

private val Colors = darkColorScheme(
    primary = Ember,
    onPrimary = Color(0xFF2A1700),
    secondary = Tide,
    background = Night,
    onBackground = Paper,
    surface = Dusk,
    onSurface = Paper,
    surfaceVariant = Twilight,
    onSurfaceVariant = Mist,
    outline = Color(0xFF4A5290),
    error = Coral
)

private val Type = Typography(
    headlineLarge = TextStyle(
        fontFamily = FontFamily.Serif, fontWeight = FontWeight.Normal,
        fontSize = 44.sp, lineHeight = 48.sp, letterSpacing = (-0.5).sp
    ),
    headlineMedium = TextStyle(
        fontFamily = FontFamily.Serif, fontWeight = FontWeight.Normal,
        fontSize = 30.sp, lineHeight = 36.sp
    ),
    titleLarge = TextStyle(
        fontFamily = FontFamily.Serif, fontWeight = FontWeight.Normal,
        fontSize = 22.sp, lineHeight = 28.sp
    ),
    titleMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 16.sp, lineHeight = 22.sp),
    bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 24.sp),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 21.sp),
    bodySmall = TextStyle(fontSize = 12.sp, lineHeight = 18.sp),
    labelMedium = TextStyle(fontWeight = FontWeight.Medium, fontSize = 12.sp, lineHeight = 16.sp)
)

@Composable
fun LumenTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Colors, typography = Type, content = content)
}
