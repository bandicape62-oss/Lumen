package dev.lumen.launcher.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PackScannerTest {

    private fun scan(files: Map<String, String>): ScanResult =
        PackScanner.scan(InMemoryPackSource(files), "TestPack")

    @Test
    fun rejectsZipWithoutShadersFolder() {
        val r = scan(mapOf("pack.mcmeta" to "{}", "textures/a.png" to ""))
        assertTrue(r is ScanResult.Invalid)
    }

    @Test
    fun simplePackIsGoodCompat() {
        val r = scan(
            mapOf(
                "shaders/gbuffers_terrain.vsh" to "#version 120\nvoid main(){}",
                "shaders/gbuffers_terrain.fsh" to "#version 120\nvoid main(){}",
                "shaders/composite.fsh" to "#version 120\nvoid main(){}"
            )
        ) as ScanResult.Valid
        assertEquals(Compat.GOOD, r.info.compat)
        assertEquals(1, r.info.passCount)
        assertEquals(120, r.info.maxGlslVersion)
    }

    @Test
    fun geometryShaderMakesPackPoor() {
        val r = scan(
            mapOf(
                "shaders/gbuffers_water.fsh" to "#version 330\nvoid main(){}",
                "shaders/gbuffers_water.gsh" to "#version 330\nvoid main(){}"
            )
        ) as ScanResult.Valid
        assertEquals(Compat.POOR, r.info.compat)
    }

    @Test
    fun shadowMapAndDimensionsAreDetected() {
        val r = scan(
            mapOf(
                "shaders/shadow.fsh" to "#version 120\nconst int shadowMapResolution = 4096;",
                "shaders/world-1/composite.fsh" to "#version 120",
                "shaders/world0/composite.fsh" to "#version 120"
            )
        ) as ScanResult.Valid
        assertTrue(r.info.hasShadow)
        assertEquals(listOf("world-1", "world0"), r.info.dimensions)
        assertEquals(Compat.PARTIAL, r.info.compat)
    }

    @Test
    fun parsesTogglesAndChoices() {
        val src = """
            #define WAVES
            //#define FANCY_SKY
            #define SHADOW_QUALITY 2 // [1 2 3]
            const float sunPathRotation = 30.0; // [0.0 30.0 60.0]
            #define PI 3.14159
        """.trimIndent()
        val opts = OptionParser.parse("shaders/lib/settings.glsl", src).associateBy { it.name }

        assertEquals(PackOption.Kind.TOGGLE, opts.getValue("WAVES").kind)
        assertEquals("1", opts.getValue("WAVES").default)
        assertEquals("0", opts.getValue("FANCY_SKY").default)
        assertEquals(listOf("1", "2", "3"), opts.getValue("SHADOW_QUALITY").values)
        assertEquals("30.0", opts.getValue("sunPathRotation").default)
        assertFalse("PI" in opts)
    }

    @Test
    fun ignoresIncludeGuards() {
        val src = "#ifndef COMMON_GLSL\n#define COMMON_GLSL\n#define REAL_OPTION\n"
        val names = OptionParser.parse("x.glsl", src).map { it.name }
        assertEquals(listOf("REAL_OPTION"), names)
    }

    @Test
    fun propertiesSupportLineContinuation() {
        val props = PropertiesParser.parse(
            "# comentario\nsliders = A B \\\n  C D\nblock.10 = minecraft:stone\n"
        )
        assertEquals("A B C D", props["sliders"])
        assertEquals("minecraft:stone", props["block.10"])
    }

    @Test
    fun zipRootFolderIsDetected() {
        val names = listOf("MiPack/shaders/composite.fsh", "MiPack/pack.png")
        assertEquals("MiPack/", ZipPackSource.detectRoot(names))
        assertEquals("", ZipPackSource.detectRoot(listOf("shaders/composite.fsh")))
    }
}
