# Motor propio de Lumen (fase 2)

Código propio, sin reutilizar nada de MagicLoader ni de otros motores.

## Estado

| Pieza | Estado |
|---|---|
| `applyOptions`: aplica las opciones guardadas en `launch_config.json` a cada `.glsl/.fsh/.vsh` | hecho, probado en PC |
| `translateToGles`: GLSL de escritorio 1.10–3.30 (OptiFine/Iris) a GLSL ES 3.00 | hecho, probado en PC (solo comparación de texto) |
| `planPasses`: orden begin → prepare → deferred → composite → final, `DRAWBUFFERS`/`RENDERTARGETS`, carpeta de dimensión | hecho, probado en PC |
| `DynamicResolution` y cadencia de sombras (valores de los perfiles Calidad/Equilibrado/Rendimiento) | hecho, probado en PC |
| Ejecutor de pasadas en GLES (FBOs, `colortex0-7`, uniforms de OptiFine, texturas de ruido) | **sin hacer** |
| Capa de enganche con Minecraft Bedrock (captura de profundidad, normales y sombras del juego) | **sin hacer** |

Las pruebas (`tests/test_core.cpp`) se compilan con g++ en PC. Nada se ha compilado con un compilador GLSL
real ni ejecutado en un móvil.

## Límites del traductor (es de texto, no un parser)

- Solo arregla `float x = 1;`. Otras conversiones int→float implícitas (`pow(x, 2)`) generan un aviso y
  GLSL ES las rechaza al compilar.
- Geometry shaders, compute, `imageLoad/imageStore` y SSBO se marcan como error: esa pasada se omite.
- Los atributos propios del pack (`mc_Entity`, `at_tangent`) necesitan `glBindAttribLocation` en el ejecutor.
- Camino de mejora si hace falta robustez: sustituir el traductor por glslang + SPIRV-Cross.

## Fases

1. **2a (hecha):** este núcleo portable.
2. **2b:** ejecutor GLES de pasadas, probado primero sobre una imagen fija en el propio móvil (sin Minecraft).
3. **2c:** capa de enganche con Bedrock. Empezar solo por registrar qué símbolos EGL/GLES importa
   `libminecraftpe.so` de la versión instalada. El riesgo principal es que los puntos de enganche cambian
   entre versiones del juego.
4. **2d:** tabla de equivalencias de bloques Java → Bedrock para `block.properties`.

## Compilar

PC: `cmake -S . -B build && cmake --build build && ctest --test-dir build`.
Android: el workflow `.github/workflows/engine.yml` compila `liblumen_engine.so` (arm64-v8a) con el NDK de GitHub.
