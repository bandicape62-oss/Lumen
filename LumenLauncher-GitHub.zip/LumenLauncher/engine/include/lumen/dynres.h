#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>

namespace lumen {

// Dynamic resolution: lowers the render scale when the GPU misses the frame budget and raises it
// again after a sustained period with headroom. Values come from OptimizationProfile.
class DynamicResolution {
public:
    DynamicResolution(double targetFps, double minScale, double maxScale, bool enabled)
        : budgetMs_(1000.0 / targetFps), min_(minScale), max_(maxScale), enabled_(enabled), scale_(maxScale) {}

    // Call once per frame with the measured frame time. Returns the scale to use next frame.
    double update(double frameMs) {
        if (!enabled_) return scale_ = max_;
        ema_ = ema_ == 0 ? frameMs : ema_ * 0.9 + frameMs * 0.1;
        if (cooldown_ > 0) --cooldown_;
        if (ema_ > budgetMs_ * 1.05 && cooldown_ == 0) {
            scale_ = quantize(std::max(min_, scale_ - 0.05));
            cooldown_ = 10; calm_ = 0;
        } else if (ema_ < budgetMs_ * 0.80) {
            if (++calm_ >= 90) { scale_ = quantize(std::min(max_, scale_ + 0.05)); calm_ = 0; cooldown_ = 10; }
        } else calm_ = 0;
        return scale_;
    }
    double scale() const { return scale_; }

private:
    static double quantize(double s) { return std::round(s * 20.0) / 20.0; }
    double budgetMs_, min_, max_;
    bool enabled_;
    double scale_, ema_ = 0;
    int cooldown_ = 0, calm_ = 0;
};

// Shadow map refresh cadence (profile.shadowUpdateEvery): render shadows every Nth frame.
inline bool shouldUpdateShadow(std::uint64_t frame, int every) { return every <= 1 || frame % every == 0; }

}  // namespace lumen
