#pragma once
#include <map>
#include <string>
#include <vector>

namespace lumen {

enum class Stage { Vertex, Fragment };

struct TranslateResult {
    std::string source;                 // GLSL ES 3.00
    std::vector<std::string> warnings;  // compiled anyway, may misbehave
    std::vector<std::string> errors;    // cannot run on GLES 3.0: skip this pass
    bool ok() const { return errors.empty(); }
};

// Applies the user's pack options (launch_config.json -> pack.options) to a shader file.
// Toggles: "1" -> `#define X`, "0" -> `//#define X`. Choices/consts: replaces the value.
std::string applyOptions(const std::string& src, const std::map<std::string, std::string>& options);

// Desktop GLSL 1.10-3.30 (OptiFine/Iris style, compatibility profile) -> GLSL ES 3.00.
// Text-level translation: covers the usual post-process packs. See ENGINE.md for limits.
TranslateResult translateToGles(const std::string& src, Stage stage);

}  // namespace lumen
