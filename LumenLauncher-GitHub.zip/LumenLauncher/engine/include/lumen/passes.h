#pragma once
#include <functional>
#include <string>
#include <vector>

namespace lumen {

enum class PassKind { Begin = 0, Prepare = 1, Deferred = 2, Composite = 3, Final = 4 };

struct Pass {
    std::string name;            // "composite2"
    PassKind kind;
    std::string vsh;             // path inside the pack, empty -> use kFullscreenVertex
    std::string fsh;
    std::vector<int> drawBuffers;  // colortex indices this pass writes (default {0})
};

// Full-screen vertex shader used when a pass has no .vsh (GLSL ES 3.00).
extern const char* const kFullscreenVertex;

// Orders the post-process passes of a pack: begin* -> prepare* -> deferred* -> composite* -> final.
// `files` are pack-relative paths (e.g. "shaders/composite1.fsh"). `dimension` like "world0" looks
// in shaders/<dimension>/ first and falls back to shaders/.
std::vector<Pass> planPasses(const std::vector<std::string>& files,
                             const std::function<std::string(const std::string&)>& readText,
                             const std::string& dimension = "");

}  // namespace lumen
