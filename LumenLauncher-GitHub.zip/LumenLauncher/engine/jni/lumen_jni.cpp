#include <jni.h>

#include <string>

#include "lumen/glsl_translate.h"

// Kotlin: object dev.lumen.launcher.NativeEngine { external fun translate(source: String, vertex: Boolean): String }
// Returns GLSL ES 3.00, or "!<reason>" when the shader cannot run on GLES 3.0.
extern "C" JNIEXPORT jstring JNICALL
Java_dev_lumen_launcher_NativeEngine_translate(JNIEnv* env, jobject /*self*/, jstring source, jboolean vertex) {
    const char* chars = env->GetStringUTFChars(source, nullptr);
    std::string src(chars ? chars : "");
    if (chars) env->ReleaseStringUTFChars(source, chars);
    lumen::TranslateResult r = lumen::translateToGles(src, vertex ? lumen::Stage::Vertex : lumen::Stage::Fragment);
    std::string out = r.ok() ? r.source : "!" + r.errors.front();
    return env->NewStringUTF(out.c_str());
}
