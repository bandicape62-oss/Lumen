#include "lumen/glsl_translate.h"

#include <regex>
#include <set>

namespace lumen {
namespace {

std::vector<std::string> splitLines(const std::string& s) {
    std::vector<std::string> out; std::string cur;
    for (char c : s) {
        if (c == '\r') continue;
        if (c == '\n') { out.push_back(cur); cur.clear(); } else cur += c;
    }
    out.push_back(cur);
    return out;
}
std::string joinLines(const std::vector<std::string>& v) {
    std::string o;
    for (size_t i = 0; i < v.size(); ++i) { if (i) o += '\n'; o += v[i]; }
    return o;
}
bool found(const std::string& s, const char* re) { return std::regex_search(s, std::regex(re)); }
std::string sub(const std::string& s, const char* re, const std::string& to) { return std::regex_replace(s, std::regex(re), to); }
std::set<int> indices(const std::string& s, const char* re) {
    std::set<int> r; std::regex rx(re);
    for (auto it = std::sregex_iterator(s.begin(), s.end(), rx); it != std::sregex_iterator(); ++it) r.insert(std::stoi((*it)[1]));
    return r;
}
std::string rtrim(std::string s) { while (!s.empty() && (s.back() == ' ' || s.back() == '\t')) s.pop_back(); return s; }

}  // namespace

// ---------------------------------------------------------------- options

std::string applyOptions(const std::string& src, const std::map<std::string, std::string>& options) {
    if (options.empty()) return src;
    static const std::regex DISABLED(R"(^(\s*)//\s*#\s*define\s+([A-Za-z_]\w*)\s*(?://.*)?$)");
    static const std::regex ACTIVE(R"(^(\s*)#\s*define\s+([A-Za-z_]\w*)(?:[ \t]+(.*?))?\s*$)");
    static const std::regex CONST(R"(^(\s*const\s+(?:int|float|bool)\s+)([A-Za-z_]\w*)(\s*=\s*)([^;]+)(;.*)$)");
    std::vector<std::string> out;
    for (const std::string& raw : splitLines(src)) {
        std::string line = rtrim(raw); std::smatch m;
        auto opt = [&](const std::string& n) -> const std::string* {
            auto it = options.find(n); return it == options.end() ? nullptr : &it->second;
        };
        if (std::regex_match(line, m, DISABLED)) {
            const std::string* v = opt(m[2]);
            if (v && *v == "1") { out.push_back(m[1].str() + "#define " + m[2].str()); continue; }
        } else if (std::regex_match(line, m, ACTIVE)) {
            const std::string* v = opt(m[2]);
            if (v) {
                std::string rest = m[3].matched ? m[3].str() : "";
                if (rest.empty()) {  // toggle
                    if (*v == "0") { out.push_back(m[1].str() + "//#define " + m[2].str()); continue; }
                } else {             // choice: replace the value, keep the trailing comment
                    size_t c = rest.find("//");
                    std::string comment = c == std::string::npos ? "" : " " + rest.substr(c);
                    out.push_back(m[1].str() + "#define " + m[2].str() + " " + *v + comment); continue;
                }
            }
        } else if (std::regex_match(line, m, CONST)) {
            const std::string* v = opt(m[2]);
            if (v) { out.push_back(m[1].str() + m[2].str() + m[3].str() + *v + m[5].str()); continue; }
        }
        out.push_back(raw);
    }
    return joinLines(out);
}

// ---------------------------------------------------------------- translation

TranslateResult translateToGles(const std::string& input, Stage stage) {
    TranslateResult r;
    const bool vs = stage == Stage::Vertex;
    int version = 110;

    // 1. Drop #version and #extension (ES 3.00 takes neither from desktop sources).
    std::vector<std::string> kept;
    for (const std::string& line : splitLines(input)) {
        std::smatch m;
        if (std::regex_search(line, m, std::regex(R"(^\s*#\s*version\s+(\d+))"))) { version = std::stoi(m[1]); kept.push_back(""); continue; }
        if (std::regex_search(line, std::regex(R"(^\s*#\s*extension\b)"))) { kept.push_back(""); continue; }
        kept.push_back(line);
    }
    std::string s = joinLines(kept);

    // 2. Features GLES 3.0 cannot run at all.
    if (found(s, R"(\b(imageLoad|imageStore|imageAtomic\w*)\b)")) r.errors.push_back("imageLoad/imageStore requiere GLES 3.1");
    if (found(s, R"(\bstd430\b|\bbuffer\s+\w+\s*\{)")) r.errors.push_back("Los buffers de almacenamiento (SSBO) requieren GLES 3.1");
    if (found(s, R"(\bgl_FragData\s*\[\s*[^0-9\s])")) r.errors.push_back("gl_FragData con indice dinamico no existe en GLES");
    if (version >= 400) r.warnings.push_back("GLSL " + std::to_string(version) + ": puede usar funciones sin equivalente en ES 3.00");
    if (found(s, R"(\bgl_Fog\b)")) r.warnings.push_back("gl_Fog no existe en GLES; se ignora");
    if (found(s, R"(\b(pow|max|min|mix|clamp|mod|step|smoothstep)\s*\([^;]*[ ,(]\d+\s*[,)])"))
        r.warnings.push_back("Posible conversion implicita int->float (p. ej. pow(x, 2)); GLSL ES la rechaza");

    // 3. Texture function names and the one implicit conversion we can fix safely.
    s = sub(s, R"(\btexture2DProjLod\s*\()", "textureProjLod(");
    s = sub(s, R"(\btexture2DProj\s*\()", "textureProj(");
    s = sub(s, R"(\btexture2DLod\s*\()", "textureLod(");
    s = sub(s, R"(\btexture2DGrad\s*\()", "textureGrad(");
    s = sub(s, R"(\b(texture2D|textureCube|texture3D)\s*\()", "texture(");
    s = sub(s, R"(\b(float\s+\w+\s*=\s*)(\d+)(\s*[;,]))", "$1$2.0$3");

    // 4. Storage qualifiers.
    if (vs) { s = sub(s, R"(\battribute\b)", "in"); s = sub(s, R"(\bvarying\b)", "out"); }
    else    { s = sub(s, R"(\bvarying\b)", "in"); }

    // 5. Compatibility built-ins -> declared lumen_* names (identifiers starting with gl_ are reserved).
    std::string decl, helpers;
    auto has = [&](const char* re) { return found(s, re); };
    struct Attr { const char* from; const char* to; const char* type; int loc; };
    static const Attr attrs[] = {{"gl_Vertex", "lumen_Vertex", "vec4", 0}, {"gl_Color", "lumen_Color", "vec4", 1},
                                 {"gl_MultiTexCoord0", "lumen_MultiTexCoord0", "vec4", 2},
                                 {"gl_MultiTexCoord1", "lumen_MultiTexCoord1", "vec4", 3}, {"gl_Normal", "lumen_Normal", "vec3", 4}};
    struct Uni { const char* from; const char* to; const char* type; };
    static const Uni unis[] = {{"gl_ModelViewMatrix", "lumen_ModelViewMatrix", "mat4"}, {"gl_ProjectionMatrix", "lumen_ProjectionMatrix", "mat4"},
                               {"gl_ModelViewProjectionMatrix", "lumen_ModelViewProjectionMatrix", "mat4"}, {"gl_NormalMatrix", "lumen_NormalMatrix", "mat3"},
                               {"gl_ModelViewMatrixInverse", "lumen_ModelViewMatrixInverse", "mat4"}, {"gl_ProjectionMatrixInverse", "lumen_ProjectionMatrixInverse", "mat4"},
                               {"gl_ModelViewProjectionMatrixInverse", "lumen_ModelViewProjectionMatrixInverse", "mat4"}};
    bool ftransform = vs && has(R"(\bftransform\s*\()");
    if (vs) {
        for (const Attr& a : attrs) {
            bool used = has(("\\b" + std::string(a.from) + "\\b").c_str()) || (ftransform && std::string(a.from) == "gl_Vertex");
            if (used) decl += "layout(location = " + std::to_string(a.loc) + ") in " + a.type + " " + a.to + ";\n";
            s = sub(s, ("\\b" + std::string(a.from) + "\\b").c_str(), a.to);
        }
        if (has(R"(\bgl_FrontColor\b)")) { decl += "out vec4 lumen_FrontColor;\n"; s = sub(s, R"(\bgl_FrontColor\b)", "lumen_FrontColor"); }
        if (has(R"(\bgl_FogFragCoord\b)")) { decl += "out float lumen_FogFragCoord;\n"; s = sub(s, R"(\bgl_FogFragCoord\b)", "lumen_FogFragCoord"); }
    } else {
        if (has(R"(\bgl_Color\b)")) { decl += "in vec4 lumen_FrontColor;\n"; s = sub(s, R"(\bgl_Color\b)", "lumen_FrontColor"); }
        if (has(R"(\bgl_FogFragCoord\b)")) { decl += "in float lumen_FogFragCoord;\n"; s = sub(s, R"(\bgl_FogFragCoord\b)", "lumen_FogFragCoord"); }
    }
    bool needMVP = ftransform;
    for (const Uni& u : unis) {
        bool used = has(("\\b" + std::string(u.from) + "\\b").c_str()) || (needMVP && std::string(u.from) == "gl_ModelViewProjectionMatrix");
        if (used) decl += std::string("uniform ") + u.type + " " + u.to + ";\n";
        s = sub(s, ("\\b" + std::string(u.from) + "\\b").c_str(), u.to);
    }
    if (has(R"(\bgl_TextureMatrix\b)")) { decl += "uniform mat4 lumen_TextureMatrix[8];\n"; s = sub(s, R"(\bgl_TextureMatrix\b)", "lumen_TextureMatrix"); }
    for (int n : indices(s, R"(\bgl_TexCoord\s*\[\s*(\d+)\s*\])")) decl += std::string(vs ? "out" : "in") + " vec4 lumen_TexCoord" + std::to_string(n) + ";\n";
    s = sub(s, R"(\bgl_TexCoord\s*\[\s*(\d+)\s*\])", "lumen_TexCoord$1");
    if (ftransform) helpers += "vec4 ftransform() { return lumen_ModelViewProjectionMatrix * lumen_Vertex; }\n";

    if (!vs) {
        std::set<int> outs = indices(s, R"(\bgl_FragData\s*\[\s*(\d+)\s*\])");
        if (has(R"(\bgl_FragColor\b)")) outs.insert(0);
        for (int n : outs) decl += "layout(location = " + std::to_string(n) + ") out vec4 lumen_FragData" + std::to_string(n) + ";\n";
        s = sub(s, R"(\bgl_FragData\s*\[\s*(\d+)\s*\])", "lumen_FragData$1");
        s = sub(s, R"(\bgl_FragColor\b)", "lumen_FragData0");
    }
    if (has(R"(\bshadow2D\s*\()")) helpers += "vec4 shadow2D(sampler2DShadow s, vec3 c) { return vec4(texture(s, c)); }\n";

    r.source = "#version 300 es\nprecision highp float;\nprecision highp int;\nprecision highp sampler2D;\n"
               "precision highp sampler3D;\nprecision highp sampler2DShadow;\n" + decl + helpers + "#line 1\n" + s;
    return r;
}

}  // namespace lumen
