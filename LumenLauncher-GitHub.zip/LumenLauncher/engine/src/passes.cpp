#include "lumen/passes.h"

#include <algorithm>
#include <regex>
#include <set>

namespace lumen {

const char* const kFullscreenVertex =
    "#version 300 es\n"
    "out vec2 texcoord;\n"
    "void main() {\n"
    "    vec2 p = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));\n"  // 3 vertices cover the screen
    "    texcoord = p;\n"
    "    gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0);\n"
    "}\n";

namespace {
std::vector<int> parseDrawBuffers(const std::string& text) {
    static const std::regex RE(R"(/\*\s*(?:DRAWBUFFERS|RENDERTARGETS)\s*:\s*([0-9, ]+?)\s*\*/)");
    std::smatch m;
    std::vector<int> out;
    if (std::regex_search(text, m, RE)) {
        std::string v = m[1];
        if (v.find(',') != std::string::npos) {
            size_t i = 0;
            while (i < v.size()) {
                size_t j = v.find(',', i); if (j == std::string::npos) j = v.size();
                std::string t = v.substr(i, j - i);
                t.erase(std::remove(t.begin(), t.end(), ' '), t.end());
                if (!t.empty()) out.push_back(std::stoi(t));
                i = j + 1;
            }
        } else {
            for (char c : v) if (c >= '0' && c <= '9') out.push_back(c - '0');
        }
    }
    if (out.empty()) out.push_back(0);
    return out;
}
}  // namespace

std::vector<Pass> planPasses(const std::vector<std::string>& files,
                             const std::function<std::string(const std::string&)>& readText,
                             const std::string& dimension) {
    std::set<std::string> have(files.begin(), files.end());
    auto resolve = [&](const std::string& base, const char* ext) -> std::string {
        if (!dimension.empty()) { std::string p = "shaders/" + dimension + "/" + base + ext; if (have.count(p)) return p; }
        std::string p = "shaders/" + base + ext;
        return have.count(p) ? p : "";
    };
    static const std::regex NAME(R"(^(begin|prepare|deferred|composite)(\d*)(_[a-z])?$)");
    struct Key { int kind; int num; std::string suffix; std::string name; };
    std::vector<Key> keys; std::set<std::string> seen;
    for (const std::string& f : files) {
        size_t slash = f.find_last_of('/'), dot = f.find_last_of('.');
        if (dot == std::string::npos || f.substr(dot) != ".fsh" || f.rfind("shaders/", 0) != 0) continue;
        std::string base = f.substr(slash + 1, dot - slash - 1), dir = f.substr(0, slash + 1);
        if (dir != "shaders/" && (dimension.empty() || dir != "shaders/" + dimension + "/")) continue;
        if (!seen.insert(base).second) continue;
        std::smatch m;
        if (base == "final") { keys.push_back({4, 0, "", base}); continue; }
        if (!std::regex_match(base, m, NAME)) continue;
        int kind = m[1] == "begin" ? 0 : m[1] == "prepare" ? 1 : m[1] == "deferred" ? 2 : 3;
        keys.push_back({kind, m[2].length() ? std::stoi(m[2]) : 0, m[3].str(), base});
    }
    std::sort(keys.begin(), keys.end(), [](const Key& a, const Key& b) {
        if (a.kind != b.kind) return a.kind < b.kind;
        if (a.num != b.num) return a.num < b.num;
        return a.suffix < b.suffix;
    });
    std::vector<Pass> out;
    for (const Key& k : keys) {
        Pass p; p.name = k.name; p.kind = static_cast<PassKind>(k.kind);
        p.fsh = resolve(k.name, ".fsh"); p.vsh = resolve(k.name, ".vsh");
        p.drawBuffers = parseDrawBuffers(readText(p.fsh));
        out.push_back(p);
    }
    return out;
}

}  // namespace lumen
