#include <cstdio>
#include <map>
#include "lumen/dynres.h"
#include "lumen/glsl_translate.h"
#include "lumen/passes.h"

static int failures = 0;
#define CHECK(c) do { if (!(c)) { std::printf("FAIL line %d: %s\n", __LINE__, #c); ++failures; } } while (0)
static bool has(const std::string& s, const std::string& t) { return s.find(t) != std::string::npos; }

using namespace lumen;

static void testVertex() {
    auto r = translateToGles("#version 120\nvarying vec2 texcoord;\nvoid main() {\n gl_Position = ftransform();\n texcoord = gl_MultiTexCoord0.st;\n}\n", Stage::Vertex);
    CHECK(r.ok());
    CHECK(has(r.source, "#version 300 es"));
    CHECK(has(r.source, "out vec2 texcoord;"));
    CHECK(has(r.source, "layout(location = 2) in vec4 lumen_MultiTexCoord0;"));
    CHECK(has(r.source, "layout(location = 0) in vec4 lumen_Vertex;"));
    CHECK(has(r.source, "uniform mat4 lumen_ModelViewProjectionMatrix;"));
    CHECK(has(r.source, "vec4 ftransform()"));
    CHECK(!has(r.source, "gl_MultiTexCoord0"));
    CHECK(!has(r.source, "#version 120"));
}

static void testFragment() {
    auto r = translateToGles("#version 120\n#extension GL_ARB_shader_texture_lod : enable\n/* DRAWBUFFERS:01 */\nuniform sampler2D colortex0;\nvarying vec2 texcoord;\n"
                             "void main() {\n vec4 c = texture2D(colortex0, texcoord);\n float a = 1;\n gl_FragData[0] = c * a;\n gl_FragData[1] = vec4(1.0);\n}\n", Stage::Fragment);
    CHECK(r.ok());
    CHECK(has(r.source, "in vec2 texcoord;"));
    CHECK(has(r.source, "texture(colortex0, texcoord)"));
    CHECK(has(r.source, "float a = 1.0;"));
    CHECK(has(r.source, "layout(location = 0) out vec4 lumen_FragData0;"));
    CHECK(has(r.source, "layout(location = 1) out vec4 lumen_FragData1;"));
    CHECK(!has(r.source, "gl_FragData"));
    CHECK(!has(r.source, "#extension"));
    auto c = translateToGles("#version 120\nvoid main(){ gl_FragColor = vec4(1.0); }", Stage::Fragment);
    CHECK(has(c.source, "lumen_FragData0 = vec4(1.0)"));
    auto sh = translateToGles("uniform sampler2DShadow shadow;\nvoid main(){ float s = shadow2D(shadow, vec3(0.5)).x; gl_FragColor = vec4(s); }", Stage::Fragment);
    CHECK(has(sh.source, "vec4 shadow2D(sampler2DShadow s, vec3 c)"));
}

static void testErrors() {
    CHECK(!translateToGles("#version 430\nlayout(rgba8) uniform image2D img;\nvoid main(){ imageStore(img, ivec2(0), vec4(1)); }", Stage::Fragment).ok());
    CHECK(!translateToGles("void main(){ int i = 0; gl_FragData[i] = vec4(1.0); }", Stage::Fragment).ok());
    auto w = translateToGles("#version 120\nvoid main(){ float x = pow(0.5, 2); gl_FragColor = vec4(x); }", Stage::Fragment);
    CHECK(w.ok() && !w.warnings.empty());
}

static void testOptions() {
    std::string src = "#define BLOOM\n//#define FOG\n#define STRENGTH 1.0 // [0.5 1.0 2.0]\nconst int shadowMapResolution = 2048; // [1024 2048]\n#define KEEP\n";
    std::string out = applyOptions(src, {{"BLOOM", "0"}, {"FOG", "1"}, {"STRENGTH", "2.0"}, {"shadowMapResolution", "1024"}});
    CHECK(has(out, "//#define BLOOM"));
    CHECK(has(out, "\n#define FOG\n"));
    CHECK(has(out, "#define STRENGTH 2.0 // [0.5 1.0 2.0]"));
    CHECK(has(out, "const int shadowMapResolution = 1024; // [1024 2048]"));
    CHECK(has(out, "#define KEEP"));
    CHECK(applyOptions(src, {}) == src);
}

static void testPasses() {
    std::vector<std::string> files = {"shaders/final.fsh", "shaders/composite10.fsh", "shaders/composite2.fsh", "shaders/composite.fsh", "shaders/composite.vsh",
                                      "shaders/deferred.fsh", "shaders/prepare.fsh", "shaders/gbuffers_terrain.fsh", "shaders/world-1/composite.fsh", "shaders/shadow.fsh"};
    auto read = [](const std::string& p) -> std::string {
        if (p == "shaders/composite.fsh") return "/* DRAWBUFFERS:012 */";
        if (p == "shaders/composite2.fsh") return "/* RENDERTARGETS: 0,3 */";
        return "";
    };
    auto passes = planPasses(files, read);
    std::vector<std::string> names; for (auto& p : passes) names.push_back(p.name);
    std::vector<std::string> want = {"prepare", "deferred", "composite", "composite2", "composite10", "final"};
    CHECK(names == want);
    CHECK(passes[2].vsh == "shaders/composite.vsh" && passes[3].vsh.empty());
    CHECK((passes[2].drawBuffers == std::vector<int>{0, 1, 2}));
    CHECK((passes[3].drawBuffers == std::vector<int>{0, 3}));
    CHECK((passes[0].drawBuffers == std::vector<int>{0}));
}

static void testDynRes() {
    DynamicResolution d(60, 0.7, 1.0, true);
    for (int i = 0; i < 300; ++i) d.update(25.0);          // 40 fps: way over the 16.6 ms budget
    CHECK(d.scale() <= 0.7001 && d.scale() >= 0.6999);
    for (int i = 0; i < 2000; ++i) d.update(8.0);          // lots of headroom: recovers
    CHECK(d.scale() > 0.99);
    DynamicResolution fixed(60, 1.0, 1.0, false);
    for (int i = 0; i < 100; ++i) fixed.update(40.0);
    CHECK(fixed.scale() == 1.0);
    CHECK(shouldUpdateShadow(0, 3) && !shouldUpdateShadow(1, 3) && shouldUpdateShadow(3, 3) && shouldUpdateShadow(5, 1));
}

int main() {
    testVertex(); testFragment(); testErrors(); testOptions(); testPasses(); testDynRes();
    std::printf(failures ? "%d FAILED\n" : "all tests passed\n", failures);
    return failures ? 1 : 0;
}
